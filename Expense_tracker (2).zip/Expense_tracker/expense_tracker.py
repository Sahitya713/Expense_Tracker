import gspread
from oauth2client.service_account import ServiceAccountCredentials
from tkinter import *
import tkinter as tk
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt 
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from tkcalendar import Calendar, DateEntry
import datetime
today = datetime.date.today()

# import spreadsheet from google sheets
scope = ['https://www.googleapis.com/auth/spreadsheets', "https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name('client_secret.json', scope)
client = gspread.authorize(creds)

sheet = client.open('Expenses').sheet1




root = tk.Tk()

##returns a list of teh categories in the current dataset and some typical expense categories
def get_cat():
    data = sheet.get_all_values()
    headers = data.pop(0)
    df = pd.DataFrame(data, columns = headers)

    categories = list()
    for category in df["Expense Category"]:
        if category not in categories:
            categories.append(category)
    typical_cats = ['food', 'bills', 'entertainment', 'social', 'office', 'shopping', 'transport']
    for i in typical_cats:
        if i not in categories:
            categories.append(i)
    if 'others' in categories:
        categories.append(categories.pop(categories.index('others')))
    else:
        categories.append('others')
    return categories

#formatting a combined string (from scroll select) to return category and amount seperately
def format_amt1(selectstr):
    amt = ''
    for i in selectstr:
        if i.isdigit() or i == '.':
            amt += i
    return amt
def format_amt2(selectstr):
    i = format_amt1(selectstr)
    i = float(i)
    if i.is_integer():
        i = str(int(i))
    else:
        i = str(i)
    return i
def format_cat(selectstr):
    cat = ''
    
    for i in selectstr:
        if i == ":":
            break
        cat += i
    return cat
    
    
## edit the selected expense 
def edit(selectstr, cell_list, display_date):
    
    frame = tk.Frame(root)
    frame.place(relwidth = 0.3, relheight = 0.5, rely = 0.2, relx = 0.7)

    tk.Label(frame, text = "Edit Expense", font ='bold').place(relwidth = 1, relheight = 0.15)
    text = "current input:" + selectstr
    tk.Label(frame, text = text).place(relwidth = 1,relheight = 0.15, rely = 0.15)
    tk.Label(frame, justify =tk.LEFT, text = "Category:").place(relwidth = 0.5, relheight = 0.15, rely = 0.45)

    tkvar = StringVar(frame)
    categories = get_cat()
    popupcat = OptionMenu(frame, tkvar, *categories)
    popupcat.place(relwidth = 0.5, relheight = 0.15, rely = 0.6)
    def editf(display_date, cell_list, selectstr, frame, value, amount):
        cat = format_cat(selectstr)
        amt1 = format_amt1(selectstr)
        amt2 = format_amt2(selectstr)
        try:
            x = float(amount)
            for cell in cell_list:
                if cat in sheet.row_values(cell.row) and (amt1 in sheet.row_values(cell.row) or amt2 in sheet.row_values(cell.row)) :
                    sheet.update_cell(cell.row,1, value)
                    sheet.update_cell(cell.row, 2, amount)
            tk.Label(frame, text = "valid Input").place(relwidth = 1, relheight = 0.1, rely = 0.9)
            display(display_date)
        except:
            tk.Label(frame, text = "Invalid Input").place(relwidth = 1, relheight = 0.1, rely = 0.9)

    def edit_amt(display_date, cell_list, selectstr, value, frame):
        tk.Label(frame, justify =tk.LEFT, text = "Amount:").place(relwidth = 0.5, relheight = 0.15, rely = 0.45, relx = 0.5)
        editamt = tk.Entry(frame)
        editamt.place(relwidth = 0.5, relheight = 0.15, rely = 0.6, relx = 0.5)
        editbtn = tk.Button(frame, text= "Edit", command = lambda: editf(display_date,cell_list,selectstr,frame,value, editamt.get()))
        editbtn.place(relwidth = 0.5, relheight = 0.15, rely = 0.75, relx = 0.25)
    def change_dropdown(*args):
        edit_amt(display_date, cell_list, selectstr, tkvar.get(), frame)

    tkvar.trace('w', change_dropdown)
    return

## delete the selected expense
def delete(selectstr, cell_list, display_date):
    cat = format_cat(selectstr)
    amt1 = format_amt1(selectstr)
    amt2 = format_amt2(selectstr)
    for cell in cell_list:
        if cat in sheet.row_values(cell.row) and (amt1 in sheet.row_values(cell.row) or amt2 in sheet.row_values(cell.row)) :
            sheet.delete_row(cell.row)
    display(display_date)

    return


#display a scrollbar with all the expenses made on selected date
def scrollbar(display_date):
    frame = tk.Frame(root)
    frame.place(relwidth = 0.3, relheight = 0.5, rely = 0.2, relx = 0.7)
    scroll=Scrollbar(frame)
    scroll.pack(side='right', fill='y')
    display_dict = {}
    cell_list = sheet.findall(display_date)
    for cell in cell_list:
        display_dict[cell.row] = sheet.row_values(cell.row)


    leftside = Listbox(frame, yscrollcommand = scroll.set)
    for key, value in display_dict.items():
        leftside.insert('end', value[0] + ": $"+ '{0:.2f}'.format(float(value[1])))

    leftside.pack(side='left', fill='both')
    scroll.config(command=leftside.yview)
    editbutton=Button(frame, text= "edit", command=lambda: edit(leftside.get('active'), cell_list, display_date))
    editbutton.pack()
    deletebutton=Button(frame, text= "delete", command=lambda: delete(leftside.get('active'), cell_list, display_date))
    deletebutton.pack()


#display a pie chart showing expenses for a selected date
def piechart(display_data):
    actualFigure = plt.figure(figsize = (10,10))
    actualFigure.suptitle("Daily Expense", fontsize = 12)

    explode = list()
    for k in display_data.keys():
        explode.append(0.1)

    pie = plt.pie(display_data.values(), labels = display_data.keys(), explode = explode, shadow = True, autopct = '%1.1f%%')

    canvas = FigureCanvasTkAgg(actualFigure, root)
    canvas.get_tk_widget().place(relwidth = 0.7, relheight = 0.5, rely = 0.2)






#display pie chart and scrollbar
def display(display_date):
    text = "Your Expenses on " + display_date
    tk.Label(root, text = text, font = 50, justify = tk.CENTER).place (relheight = 0.1, rely = 0.1, relwidth = 1)


    
    data = sheet.get_all_values()
    headers = data.pop(0)
    df = pd.DataFrame(data, columns = headers)

    categories = list()
    for category in df["Expense Category"]:
        if category not in categories:
            categories.append(category)

    display_data = {}
    for cat in categories:
        display_data[cat] = 0
    
    for category, amount, dt in df.values:
        if dt == display_date:
            display_data[category] += float(amount)

    #removing the keys with $0
    list1 = list()
    for key, value in display_data.items():
        if value == 0:
            list1.append(key)
    for key in list1:
        del display_data[key]
    if display_data == {}:
        tk.Label(root, text = 'No Expenses Recorded', font = 20).place(relwidth = 1, relheight = 0.5, rely = 0.2)
    else:
        piechart(display_data)
        scrollbar(display_date)
    
    



# select month date (default is current date )
display(str(today))
tk.Label(root, text='Choose date', font = 15, justify = tk.RIGHT).place(relwidth = 0.2, relheight  = 0.075)

cal = DateEntry(root, background='darkblue',
                    foreground='white', borderwidth=2, year=int(today.year))
cal.place(relwidth = 0.2, relheight = 0.075, relx = 0.2)
tk.Button(root, text="ok", command=lambda: display(str(cal.get_date()))).place(relwidth = 0.1, relheight = 0.075, relx = 0.4)
        






# add new expense (date->category->amt)


def add(add_date, category, amount):
    global sheet
    global root
    try:
        x = float(amount)
        max_len = len(sheet.get_all_values()) + 1
        sheet.insert_row([category, amount, add_date], max_len)
        tk.Label(root, text = "valid input").place(relwidth = 0.2, relheight = 0.05,rely = 0.95, relx = 0.8)
    except:
        tk.Label(root, text = "invalid input").place(relwidth = 0.2, relheight = 0.05,rely = 0.95, relx = 0.8)



def add_amt(add_date, category):
    global root
    tk.Label(root, justify =tk.LEFT, text = "Enter Amount").place(relwidth = 0.3, relheight = 0.1,rely = 0.8, relx = 0.6)
    amt_entry = tk.Entry(root,
                    bg = 'light yellow',
                    font = 15)
    amt_entry.place(relwidth = 0.2, relheight = 0.1,rely = 0.9, relx = 0.6)
    enter_amt = tk.Button(root,
                            text = 'ok!',
                            bg = 'light yellow',
                            font = 15,
                            command = lambda: add(add_date, category, amt_entry.get()))
    enter_amt.place(relwidth = 0.1, relheight = 0.05,rely = 0.9, relx = 0.8)

def add_category(add_date):
    tk.Label(root, justify =tk.LEFT, text = "Enter Expense Category").place(relwidth = 0.3, relheight = 0.1,rely = 0.8, relx = 0.3)

    tkvar = StringVar(root)

    categories = get_cat()

    popupcat = OptionMenu(root, tkvar, *categories)
    popupcat.place(relwidth = 0.3, relheight = 0.1,rely = 0.9, relx = 0.3)

    # on change dropdown value
    def change_dropdown(*args):
        add_amt(add_date, tkvar.get())

    # link function to change dropdown
    tkvar.trace('w', change_dropdown)


tk.Label (root, text = "Add Expense", justify = tk.CENTER, font = 20).place(relwidth = 1, relheight = 0.05,rely = 0.75)
tk.Label(root, justify =tk.LEFT, text = "Enter date").place(relwidth = 0.3, relheight = 0.1,rely = 0.8)

add_date = DateEntry(root, background='darkblue',
                    foreground='white', borderwidth=2, year=int(today.year))
add_date.place(relwidth = 0.2, relheight = 0.1,rely = 0.9)
tk.Button(root, text="ok", command=lambda: add_category(str(add_date.get_date()))).place(relwidth = 0.1, relheight = 0.1,rely = 0.9, relx = 0.2)






root.title("Expense Tracker")
root.geometry("600x600+120+120")
root.mainloop()